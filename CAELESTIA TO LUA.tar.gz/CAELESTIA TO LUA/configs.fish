#!/usr/bin/env fish

set -l _reload false

# Ensure config directory exists
if ! test -d $argv
    mkdir -p $argv
end

# Ensure hypr-vars exists
if ! test -f $argv/hypr-vars.lua
    touch -a $argv/hypr-vars.lua
    set -l _reload true
end

# Ensure hypr-user exists
if ! test -f $argv/hypr-user.lua
    touch -a $argv/hypr-user.lua
    set -l _reload true
end

# Reload as needed
if _reload
    hyprctl reload
end
