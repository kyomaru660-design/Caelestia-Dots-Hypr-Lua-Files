-- Color palette (Material You / Catppuccin-mapped scheme)
-- Source: scheme/default.conf equivalent
-- All values are raw hex strings (no prefix), used by variables.lua and others
-- to construct rgba(...) / rgb(...) color strings.

primary_paletteKeyColor        = "7171ac"
secondary_paletteKeyColor      = "76758e"
tertiary_paletteKeyColor       = "9e648e"
neutral_paletteKeyColor        = "78767b"
neutral_variant_paletteKeyColor = "777680"

background                     = "131317"
onBackground                   = "e5e1e7"
surface                        = "131317"
surfaceDim                     = "131317"
surfaceBright                  = "39393d"
surfaceContainerLowest         = "0e0e12"
surfaceContainerLow            = "1c1b1f"
surfaceContainer               = "201f23"
surfaceContainerHigh           = "2a292e"
surfaceContainerHighest        = "353438"
onSurface                      = "e5e1e7"
surfaceVariant                 = "47464f"
onSurfaceVariant               = "c8c5d1"
inverseSurface                 = "e5e1e7"
inverseOnSurface               = "313034"
outline                        = "918f9a"
outlineVariant                 = "47464f"
shadow                         = "000000"
scrim                          = "000000"
surfaceTint                    = "c2c1ff"

primary                        = "c2c1ff"
onPrimary                      = "2a2a60"
primaryContainer               = "7171ac"
onPrimaryContainer             = "ffffff"
inversePrimary                 = "595992"

secondary                      = "c6c4e0"
onSecondary                    = "2e2e44"
secondaryContainer             = "45455c"
onSecondaryContainer           = "b4b2ce"

tertiary                       = "f5b2e0"
onTertiary                     = "4e1e44"
tertiaryContainer              = "bb7da9"
onTertiaryContainer            = "000000"

error                          = "ffb4ab"
onError                        = "690005"
errorContainer                 = "93000a"
onErrorContainer               = "ffdad6"

primaryFixed                   = "e2dfff"
primaryFixedDim                = "c2c1ff"
onPrimaryFixed                 = "14134a"
onPrimaryFixedVariant          = "414178"

secondaryFixed                 = "e2e0fd"
secondaryFixedDim              = "c6c4e0"
onSecondaryFixed               = "19192e"
onSecondaryFixedVariant        = "45455c"

tertiaryFixed                  = "ffd7f0"
tertiaryFixedDim               = "f5b2e0"
onTertiaryFixed                = "35082e"
onTertiaryFixedVariant         = "68355c"

-- Terminal colors
term0  = "353434"
term1  = "ac73ff"
term2  = "44def5"
term3  = "ffdcf2"
term4  = "99aad8"
term5  = "b49fea"
term6  = "9dceff"
term7  = "e8d3de"
term8  = "ac9fa9"
term9  = "c093ff"
term10 = "89ecff"
term11 = "fff0f6"
term12 = "b5c1dd"
term13 = "c9b5f4"
term14 = "bae0ff"
term15 = "ffffff"

-- Catppuccin-mapped names
rosewater = "f7eff9"
flamingo  = "e9def3"
pink      = "e2d7ff"
mauve     = "bfb8ff"
red       = "c1a5fd"
maroon    = "c9b5ed"
peach     = "e0c2f9"
yellow    = "ffecf3"
green     = "c8e3ff"
teal      = "d3dfff"
sky       = "d0daff"
sapphire  = "b7c5ff"
blue      = "b0b8ff"
lavender  = "c7c8ff"
text      = "e5e1e7"
subtext1  = "c8c5d1"
subtext0  = "918f9a"
overlay2  = "7e7c86"
overlay1  = "6b6972"
overlay0  = "595860"
surface2  = "48474e"
surface1  = "37373d"
surface0  = "25252a"
base      = "131317"
mantle    = "131317"
crust     = "121216"

-- Status colors
success          = "B5CCBA"
onSuccess        = "213528"
successContainer = "374B3E"
onSuccessContainer = "D1E9D6"

-- Helper: build an rgba() string from a hex color + 2-char alpha hex
-- e.g. rgba_hex(primary, "e6") -> "rgba(c2c1ffe6)"
function rgba_hex(color, alpha)
    return "rgba(" .. color .. alpha .. ")"
end

-- Helper: build an rgb() string from a hex color
function rgb_hex(color)
    return "rgb(" .. color .. ")"
end
