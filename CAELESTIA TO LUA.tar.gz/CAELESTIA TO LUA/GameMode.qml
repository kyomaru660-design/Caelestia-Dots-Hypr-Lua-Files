pragma Singleton

import QtQuick
import Quickshell
import Quickshell.Io
import Caelestia
import Caelestia.Config
import qs.services

Singleton {
    id: root

    property alias enabled: props.enabled

    function setDynamicConfs(): void {
        Hypr.extras.applyOptions({
            "animations:enabled": 0,
            "decoration:shadow:enabled": 0,
            "decoration:blur:enabled": 0,
            "general:gaps_in": 0,
            "general:gaps_out": 0,
            "general:border_size": 1,
            "decoration:rounding": 0,
            "general:allow_tearing": 0
        });
    }

    onEnabledChanged: {
        if (enabled) {
            setDynamicConfs();
            Quickshell.execDetached(["pkill", "mpvpaper"]);
            Quickshell.execDetached(["hyprctl", "eval", "hl.monitor({output='DP-6', mode='2560x1440@60', position='0x0', scale=1, transform=0})"]);
            Quickshell.execDetached(["hyprctl", "eval", "hl.monitor({output='DP-5', mode='2560x1440@60', position='1920x-740', scale=1, transform=3})"]);
            if (GlobalConfig.utilities.toasts.gameModeChanged)
                Toaster.toast(qsTr("Game mode enabled"), qsTr("Disabled Hyprland animations, blur, gaps and shadows"), "gamepad");
        } else {
            Hypr.extras.message("reload");
            Quickshell.execDetached(["hyprctl", "eval", "hl.monitor({output='DP-6', mode='3840x2160@144', position='0x0', scale=2, transform=0})"]);
            Quickshell.execDetached(["hyprctl", "eval", "hl.monitor({output='DP-5', mode='2560x1440@60', position='1920x-740', scale=1, transform=3})"]);
            Quickshell.execDetached(["mpvpaper", "-o", "--no-audio --loop --hwdec=auto --video-sync=display-resample", "DP-6", "/home/cody/Pictures/Live Wallpapers/nezuko_live_wallpaper.mp4"]);
            Quickshell.execDetached(["mpvpaper", "-o", "--no-audio --loop", "DP-5", "/home/cody/Pictures/Live Wallpapers/Demon_Slayer_Vertical.mp4"]);
            if (GlobalConfig.utilities.toasts.gameModeChanged)
                Toaster.toast(qsTr("Game mode disabled"), qsTr("Hyprland settings restored"), "gamepad");
        }
    }

    PersistentProperties {
        id: props

        property bool enabled: Hypr.options["animations:enabled"] === 0 // qmllint disable missing-property

        reloadableId: "gameMode"
    }

    Connections {
        function onConfigReloaded(): void {
            if (props.enabled)
                root.setDynamicConfs();
        }

        target: Hypr
    }

    IpcHandler {
        function isEnabled(): bool {
            return props.enabled;
        }

        function toggle(): void {
            props.enabled = !props.enabled;
        }

        function enable(): void {
            props.enabled = true;
        }

        function disable(): void {
            props.enabled = false;
        }

        target: "gameMode"
    }
}
